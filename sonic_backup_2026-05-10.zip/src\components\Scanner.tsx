"use client";

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { Upload, FileText, ChevronDown, AlertCircle, Mic, Camera, Image as ImageIcon, Loader2, X, Sparkles } from 'lucide-react';

import { ContextModal } from './ContextModal';
import { DisclaimerModal } from './DisclaimerModal';
import { DiagnosisReport } from './DiagnosisReport';
import { NoCreditsModal } from './NoCreditsModal';
import { LoginRequiredModal } from './LoginRequiredModal';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { useAuth } from '@clerk/nextjs';
import type { Diagnosis } from '@/types/diagnosis';
import type { DiagnosticContextData } from './ContextModal';

// Utility for smooth animation interpolation
const lerp = (start: number, end: number, factor: number) => start + (end - start) * factor;

const MAX_VIDEO_SIZE_MB = 30;
const MAX_IMAGE_SIZE_MB = 5;
const MAX_AUDIO_SIZE_MB = 10;

interface ScannerProps {
  mode?: 'audio' | 'visual';
  onOpenChat?: (id: string) => void;
}

export function Scanner({
  mode = 'visual',
  onOpenChat
}: ScannerProps) {
  const { t, language } = useLanguage();
  const { isSignedIn } = useAuth();
  const [activeMode, setActiveMode] = useState(mode);
  const [vehicleMake, setVehicleMake] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isContextModalOpen, setIsContextModalOpen] = useState(false);
  const [isDiagnosisOpen, setIsDiagnosisOpen] = useState(false);
  const [analyzingText, setAnalyzingText] = useState(t.auto.status.init);
  const [pendingHint, setPendingHint] = useState(0);
  const [diagnosisData, setDiagnosisData] = useState<Diagnosis | null>(null);
  const [diagnosisId, setDiagnosisId] = useState<string | undefined>();
  const [showNoCreditsModal, setShowNoCreditsModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [isDisclaimerModalOpen, setIsDisclaimerModalOpen] = useState(false);
  const [showDisclaimerWarning, setShowDisclaimerWarning] = useState(false);

  const PENDING_HINTS = t.auto.pendingHints;

  // New States for Follow-up Flow
  const [diagnosticContext, setDiagnosticContext] = useState<DiagnosticContextData | null>(null);
  const [isFollowUp, setIsFollowUp] = useState(false);
  const [followUpRequest, setFollowUpRequest] = useState<{ message: string, action_required: string } | null>(null);
  const [firstFiles, setFirstFiles] = useState<File[]>([]);

  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const [isDisclaimerAccepted, setIsDisclaimerAccepted] = useState(false);
  const recordingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [isLoadingFile, setIsLoadingFile] = useState(false);
  const [showContextReminder, setShowContextReminder] = useState(false);
  const [stickyError, setStickyError] = useState<string | null>(null);

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationRef = useRef<number | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // Refs for the concentric rings
  const ringsRef = useRef<(HTMLDivElement | null)[]>([]);
  // Store current scales for smooth lerping
  const currentScales = useRef<number[]>([1, 1, 1, 1, 1]);

  const startVisualizerLoop = (isDemo: boolean) => {
    const updateData = () => {
      const dataArray = new Uint8Array(128);

      if (!isDemo && analyserRef.current) {
        analyserRef.current.getByteFrequencyData(dataArray);
      } else if (isDemo) {
        // Generate fake engine-like frequency data for demo mode
        const time = Date.now() / 1000;
        for (let i = 0; i < 128; i++) {
          const noise = Math.random() * 40;
          const engineThump = Math.sin(time * 15) * 80 + 80; // Low frequency thump
          const mechanicalWhine = Math.sin(time * 2 + i * 0.1) * 40 + 40;

          // Bass gets the thump, higher freqs get the whine
          let val = 0;
          if (i < 15) val = engineThump + noise;
          else val = mechanicalWhine + noise;

          const dropoff = Math.pow(1 - (i / 128), 1.5);
          dataArray[i] = Math.min(255, Math.max(0, val * dropoff));
        }
      }

      // Calculate frequency bands
      const getAverage = (start: number, end: number) => {
        let sum = 0;
        for (let i = start; i < end; i++) sum += dataArray[i];
        return sum / (end - start);
      };

      const bass = getAverage(0, 10);
      const lowMid = getAverage(10, 30);
      const mid = getAverage(30, 60);
      const highMid = getAverage(60, 100);
      const treble = getAverage(100, 128);

      // Target scales based on frequencies (inner to outer)
      // Using Math.pow for non-linear reactions, but with softer multipliers for a calmer feel
      const targetScales = [
        1 + Math.pow(treble / 255, 1.5) * 0.3,
        1 + Math.pow(highMid / 255, 1.5) * 0.6,
        1 + Math.pow(mid / 255, 1.5) * 1.0,
        1 + Math.pow(lowMid / 255, 1.5) * 1.5,
        1 + Math.pow(bass / 255, 1.5) * 2.2
      ];

      // Smoothly interpolate scales
      for (let i = 0; i < 5; i++) {
        currentScales.current[i] = lerp(currentScales.current[i], targetScales[i], 0.05); // Extremely slow lerp for liquid feel

        if (ringsRef.current[i]) {
          const scale = currentScales.current[i];
          const intensity = targetScales[i] - 1; // How loud this band is

          // Opacity fades out as scale increases, but gets a boost from intensity
          const baseOpacity = 0.15 - (i * 0.02);
          const opacity = Math.max(0, baseOpacity - (scale - 1) * 0.04 + (intensity * 0.05));

          ringsRef.current[i]!.style.transform = `translate(-50%, -50%) scale(${scale})`;
          ringsRef.current[i]!.style.opacity = opacity.toString();

          // Dynamic color shifting based on intensity (deep blue to bright cyan)
          const r = Math.min(255, intensity * 80);
          const g = Math.min(255, 209 + intensity * 46); // #00D1FF is rgb(0, 209, 255)
          const b = 255;
          ringsRef.current[i]!.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;
        }
      }

      animationRef.current = requestAnimationFrame(updateData);
    };
    updateData();
  };

  const startRecording = async () => {
    setError(null);
    setIsDemoMode(false);
    recordedChunksRef.current = [];
    try {
      // 1. Initialize AudioContext FIRST to tie it to the user gesture (fixes iOS/Safari bugs)
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContextClass();
      if (audioCtx.state === 'suspended') {
        await audioCtx.resume();
      }
      audioContextRef.current = audioCtx;

      // 2. Request microphone access
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // 3. Set up analyzer
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      analyser.smoothingTimeConstant = 0.9; // Extremely high smoothing for liquid, non-jittery reaction
      analyserRef.current = analyser;

      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);

      // 4. Start MediaRecorder to capture real audio data
      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : 'audio/webm';
      const recorder = new MediaRecorder(stream, { mimeType });
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunksRef.current.push(e.data);
      };
      recorder.start();
      mediaRecorderRef.current = recorder;

      setIsRecording(true);
      startVisualizerLoop(false);

      // Zatrzymanie nagrywania po 30 sekundach (zabezpieczenie przed widmem)
      if (recordingTimeoutRef.current) clearTimeout(recordingTimeoutRef.current);
      recordingTimeoutRef.current = setTimeout(async () => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
          const audioFile = await stopRecording();
          if (audioFile) setPendingFiles(prev => [...prev, audioFile]);
        }
      }, 30000);
    } catch (err) {
      console.warn("Microphone access denied or error:", err);
      setError(t.auto.noMic);
      setIsDemoMode(true);
      setIsRecording(true);
      startVisualizerLoop(true);
    }
  };

  const stopRecording = (): Promise<File | null> => {
    return new Promise((resolve) => {
      if (recordingTimeoutRef.current) {
        clearTimeout(recordingTimeoutRef.current);
        recordingTimeoutRef.current = null;
      }
      if (animationRef.current) cancelAnimationFrame(animationRef.current);

      const recorder = mediaRecorderRef.current;
      if (recorder && recorder.state !== 'inactive') {
        recorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, { type: 'audio/webm' });
          const file = new File([blob], 'recording.webm', { type: 'audio/webm' });
          recordedChunksRef.current = [];
          mediaRecorderRef.current = null;
          resolve(file);
        };
        recorder.stop();
      } else {
        resolve(null);
      }

      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') audioContextRef.current.close();

      setIsRecording(false);
      setIsDemoMode(false);

      // Reset rings to idle state smoothly
      for (let i = 0; i < 5; i++) {
        currentScales.current[i] = 1;
        if (ringsRef.current[i]) {
          ringsRef.current[i]!.style.transform = `translate(-50%, -50%) scale(1)`;
          ringsRef.current[i]!.style.opacity = '0';
        }
      }
    });
  };

  // Cancel recording without triggering analysis
  const cancelRecording = () => {
    if (recordingTimeoutRef.current) {
      clearTimeout(recordingTimeoutRef.current);
      recordingTimeoutRef.current = null;
    }
    stopRecording();
    setPendingFiles([]);
    setActiveMode('visual');
    setShowContextReminder(false);
  };

  const toggleRecording = async () => {
    if (isRecording) {
      const audioFile = await stopRecording();
      if (audioFile) {
        setPendingFiles(prev => [...prev, audioFile]);
      } else {
        setError(t.auto.errors.recordFailed);
      }
    } else {
      if (activeMode === 'visual') {
        fileInputRef.current?.click();
      } else {
        startRecording();
      }
    }
  };

  const handleAnalyzeClick = () => {
    if (pendingFiles.length === 0) return;

    if (!isDisclaimerAccepted) {
      setShowDisclaimerWarning(true);
      setTimeout(() => setShowDisclaimerWarning(false), 2000);
      return;
    }

    if (!isSignedIn) {
      setShowLoginModal(true);
      return;
    }

    if (!diagnosticContext && !vehicleMake) {
      setShowContextReminder(true);
      return;
    }

    runDiagnosis(pendingFiles, false);
  };

  const runDiagnosis = async (files: File[], forceComplete: boolean = false) => {
    if (!files || files.length === 0) {
      setIsAnalyzing(false);
      setShowContextReminder(false);
      const msg = t.auto.errors.recordFirst;
      alert(msg);
      setError(msg);
      return;
    }

    for (const file of files) {
      if (file.type.startsWith('audio/') || file.type.startsWith('video/')) {
        const url = URL.createObjectURL(file);
        const duration = await new Promise<number>((resolve) => {
          const media = document.createElement(file.type.startsWith('video/') ? 'video' : 'audio');
          media.onloadedmetadata = () => {
            URL.revokeObjectURL(url);
            resolve(media.duration);
          };
          media.onerror = () => {
            URL.revokeObjectURL(url);
            resolve(999); // Ignore on error
          };
          // Czasami duration ładuje się w nieskończoność dla surowych blobów z MediaRecordera, fallback:
          setTimeout(() => {
            URL.revokeObjectURL(url);
            resolve(999);
          }, 1500);
          media.src = url;
        });

        if (duration > 0 && duration < 1) {
          const msg = t.auto.errors.minDuration;
          alert(msg);
          setError(msg);
          return;
        }
        if (duration > 60 && file.type.startsWith('video/')) {
          const msg = t.auto.errors.maxVideoDuration;
          alert(msg);
          setError(msg);
          return;
        }
      }
    }

    // Set UI to analyzing
    setIsAnalyzing(true);
    setAnalyzingText(t.auto.status.init);
    setError(null);

    // Zbierz wszystkie pliki
    const allFilesToUpload: File[] = [];
    if (isFollowUp && firstFiles.length > 0) {
      allFilesToUpload.push(...firstFiles);
    }
    allFilesToUpload.push(...files);

    // Create form data for our backend API
    const formData = new FormData();
    formData.append("isFollowUp", isFollowUp ? "true" : "false");
    formData.append("locale", language);
    formData.append("vehicleType", "auto");
    formData.append("vehicleMake", vehicleMake || "Auto");

    // Build context text from diagnosticContext
    if (diagnosticContext) {
      const ctxParts = [];
      if (diagnosticContext.yearEngine) ctxParts.push(`Rok i Silnik: ${diagnosticContext.yearEngine}`);
      if (diagnosticContext.mileage) ctxParts.push(`${t.auto.labels.mileage} ${diagnosticContext.mileage}`);
      if (diagnosticContext.obdCodes) ctxParts.push(`${t.auto.labels.obdCodes} ${diagnosticContext.obdCodes}`);
      if (diagnosticContext.condition) ctxParts.push(`${t.auto.labels.condition} ${diagnosticContext.condition}`);
      if (diagnosticContext.tags.length > 0) ctxParts.push(`${t.auto.labels.tags} ${diagnosticContext.tags.join(', ')}`);
      if (diagnosticContext.description) ctxParts.push(`${t.auto.labels.description} ${diagnosticContext.description}`);
      formData.append("context", ctxParts.join('\n'));

      // Attach context files if any
      if (diagnosticContext.contextFiles && diagnosticContext.contextFiles.length > 0) {
        allFilesToUpload.push(...diagnosticContext.contextFiles);
      }
    }

    if (forceComplete) {
      formData.append("context", (formData.get("context") || "") + "\n\nATTENTION: User refused physical test - force final diagnosis with available data set with status 'complete'.");
    }

    let interval: NodeJS.Timeout | undefined;

    try {
      // 1. Get Signed URLs for direct GCS upload
      setAnalyzingText(t.auto.status.cloud);
      const uploadUrlResponse = await fetch("/api/upload-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          files: allFilesToUpload.map(f => ({ filename: f.name || 'file.bin', contentType: f.type || 'application/octet-stream' }))
        })
      });

      if (!uploadUrlResponse.ok) {
        throw new Error(`${t.auto.status.cloud} Error: ${uploadUrlResponse.status} ${uploadUrlResponse.statusText}`);
      }
      const uploadUrlText = await uploadUrlResponse.text();
      let urls;
      try {
        const parsed = JSON.parse(uploadUrlText);
        urls = parsed.urls;
      } catch (e) {
        console.error("Non-JSON response from /api/upload-url:", uploadUrlText);
        throw new Error(`${t.auto.status.cloud} Error: ${uploadUrlText.substring(0, 50)}`);
      }

      // 2. Upload files directly to GCS
      setAnalyzingText(t.auto.status.uploading);
      const uploadedFileParts = [];
      for (let i = 0; i < allFilesToUpload.length; i++) {
        const file = allFilesToUpload[i];
        const urlInfo = urls[i];

        const putRes = await fetch(urlInfo.signedUrl, {
          method: "PUT",
          headers: {
            "Content-Type": file.type || 'application/octet-stream'
          },
          body: file
        });

        if (!putRes.ok) throw new Error(t.auto.errors.uploadFailed);

        uploadedFileParts.push({
          fileData: {
            fileUri: urlInfo.gcsUri,
            mimeType: urlInfo.mimeType
          }
        });
      }

      // Dołącz wgrane części (JSON z URI)
      formData.append("fileParts", JSON.stringify(uploadedFileParts));

      // Mock progress messages for AI generation
      const statuses = [
        t.auto.status.audio,
        t.auto.status.engine,
        t.auto.status.db,
      ];
      let statusIndex = 0;
      interval = setInterval(() => {
        statusIndex = (statusIndex + 1) % statuses.length;
        setAnalyzingText(statuses[statusIndex]);
      }, 2500);

      // 3. Send to our API to trigger AI
      const response = await fetch("/api/diagnose", {
        method: "POST",
        body: formData,
      });

      const responseText = await response.text();
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (e) {
        console.error("Non-JSON response from /api/diagnose:", responseText);
        throw new Error(`${t.auto.errors.serverError} ${response.status} - ${responseText.substring(0, 100)}`);
      }

      clearInterval(interval);
      setIsAnalyzing(false);

      console.log('[Sonic Frontend] Response:', JSON.stringify(data, null, 2));

      if (!response.ok) {
        if (response.status === 403) {
          setShowNoCreditsModal(true);
          return;
        }
        if (response.status === 429) {
          throw new Error(t.auto.errors.rateLimit);
        }
        throw new Error(data.message || t.auto.status.error);
      }

      const aiResponse = data.aiResponse;

      // Handle AI Response based on status field
      if (aiResponse?.status === "follow_up" && aiResponse?.follow_up_request) {
        setIsFollowUp(true);
        setFollowUpRequest(aiResponse.follow_up_request);
        setFirstFiles(files);
        setPendingFiles([]); // clear so follow-up overlay shows
      } else if (aiResponse?.status === "complete" || data.diagnosis) {
        // Accept either complete status or legacy diagnosis field
        const diagnosis = aiResponse?.final_diagnosis || data.diagnosis;
        if (!diagnosis) {
          throw new Error(t.auto.errors.noDiagnosis);
        }
        setDiagnosisData(diagnosis);
        setDiagnosisId(data.diagnosisId);
        setIsDiagnosisOpen(true);
        setIsFollowUp(false);
        setFollowUpRequest(null);
        setFirstFiles([]);
        setPendingFiles([]);
      } else {
        console.error('[Sonic Frontend] Unexpected response structure:', data);
        throw new Error(t.auto.errors.unexpectedResponse);
      }

    } catch (err) {
      clearInterval(interval);
      setIsAnalyzing(false);
      const msg = err instanceof Error ? err.message : t.auto.status.error;
      setError(msg);
      setStickyError(msg); // persistent so user can always read it
    }
  };



  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setIsLoadingFile(true);
      const incomingFiles = Array.from(e.target.files);

      let currentVideos = pendingFiles.filter(f => f.type.startsWith('video/')).length;
      let currentImages = pendingFiles.filter(f => f.type.startsWith('image/')).length;
      let currentAudio = pendingFiles.filter(f => f.type.startsWith('audio/')).length;

      const acceptedFiles: File[] = [];

      for (const file of incomingFiles) {
        const sizeMB = file.size / (1024 * 1024);

        if (file.type.startsWith('video/')) {
          if (sizeMB > MAX_VIDEO_SIZE_MB) {
            alert(`${t.auto.labels.ready}: ${file.name}... ${t.auto.errors.maxSize} ${MAX_VIDEO_SIZE_MB}MB.`);
            continue;
          }
          if (currentVideos < 1) {
            acceptedFiles.push(file);
            currentVideos++;
          } else {
            alert(t.auto.errors.maxVideos);
          }
        } else if (file.type.startsWith('image/')) {
          if (sizeMB > MAX_IMAGE_SIZE_MB) {
            alert(`${t.auto.labels.ready}: ${file.name}... ${t.auto.errors.maxSize} ${MAX_IMAGE_SIZE_MB}MB.`);
            continue;
          }
          if (currentImages < 3) {
            acceptedFiles.push(file);
            currentImages++;
          } else {
            alert(t.auto.errors.maxImages);
          }
        } else if (file.type.startsWith('audio/')) {
          if (sizeMB > MAX_AUDIO_SIZE_MB) {
            alert(`${t.auto.labels.ready}: ${file.name}... ${t.auto.errors.maxSize} ${MAX_AUDIO_SIZE_MB}MB.`);
            continue;
          }
          if (currentAudio < 1 && currentVideos < 1) {
            acceptedFiles.push(file);
            currentAudio++;
          } else {
            alert(t.auto.errors.maxAudio);
          }
        } else {
          acceptedFiles.push(file);
        }
      }

      await new Promise(r => setTimeout(r, 400));
      setPendingFiles(prev => [...prev, ...acceptedFiles]);
      setIsLoadingFile(false);
      e.target.value = '';
    }
  };

  useEffect(() => {
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') audioContextRef.current.close();
    };
  }, []);

  // Cycle through hint messages when file is pending
  useEffect(() => {
    if (pendingFiles.length === 0) {
      setPendingHint(0);
      if (!isRecording && !isAnalyzing) {
        setActiveMode('visual');
      }
      return;
    }
    const id = setInterval(() => setPendingHint(h => (h + 1) % PENDING_HINTS.length), 2800);
    return () => clearInterval(id);
  }, [pendingFiles.length, isRecording, isAnalyzing]);

  return (
    <div className="h-[100dvh] bg-background text-foreground flex flex-col items-center font-sans relative overflow-hidden selection:bg-[#00D1FF]/30">
      {/* Premium Deep Navy Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,#13172B_0%,#06080F_100%)] pointer-events-none" />

      <motion.div
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.08, 0.15, 0.08],
          rotate: [0, 45, 0]
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-[-20%] left-[-10%] w-[80vw] h-[80vw] bg-gradient-to-br from-[#00D1FF] to-transparent rounded-full blur-[120px] pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.05, 0.1, 0.05],
          rotate: [0, -45, 0]
        }}
        transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-[-20%] right-[-10%] w-[70vw] h-[70vw] bg-gradient-to-tl from-[#00D1FF] to-transparent rounded-full blur-[120px] pointer-events-none"
      />

      {/* Mobile-perfect container */}
      <div className="relative z-10 w-full max-w-md mx-auto flex flex-col h-full overflow-y-auto scrollbar-hide pb-[100px] md:pb-[120px]">

        {/* Cancel button during recording or when pendingFiles.length > 0 exists — top left */}
        <AnimatePresence>
          {(isRecording || pendingFiles.length > 0) && !isAnalyzing && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.3 }}
              onClick={cancelRecording}
              className="fixed top-6 left-6 z-50 w-11 h-11 rounded-full bg-foreground/5 backdrop-blur-2xl border border-foreground/10 flex items-center justify-center hover:bg-foreground/10 transition-colors shadow-[0_4px_16px_rgba(0,0,0,0.3)]"
              aria-label="Anuluj"
            >
              <X className="w-5 h-5 text-foreground/70" strokeWidth={2} />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Top Inputs */}
        <motion.div
          animate={{ opacity: (isRecording || isAnalyzing) ? 0 : 1, y: (isRecording || isAnalyzing) ? -20 : 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="w-full px-6 flex flex-col items-center pt-16 md:pt-24 pb-1 relative z-20 gap-2 md:gap-3 shrink-0"
          style={{ pointerEvents: (isRecording || isAnalyzing) ? 'none' : 'auto' }}
        >
          <div className="w-full bg-surface/80 hover:bg-surface-hover/90 transition-all duration-500 p-3 md:p-4 rounded-[24px] md:rounded-[32px] border border-foreground/[0.05] backdrop-blur-3xl shadow-[0_8px_32px_rgba(0,0,0,0.3)] group flex flex-col gap-1 md:gap-3">
            <div className="flex flex-col items-start px-2">
              <span className="text-[10px] font-semibold tracking-widest text-[#00D1FF] uppercase mb-0.5">{t.auto.vehicleData}</span>
            </div>
            <div className="relative w-full">
              <input
                type="text"
                placeholder={t.auto.makeModelPlaceholder}
                value={vehicleMake}
                onChange={(e) => setVehicleMake(e.target.value)}
                className="w-full bg-background/50 border border-foreground/[0.05] rounded-2xl px-4 py-3 text-sm text-foreground placeholder:text-foreground/40 focus:outline-none focus:border-[#00D1FF]/40 focus:ring-1 focus:ring-[#00D1FF]/20 transition-all"
              />
            </div>
          </div>

          {/* Legal Disclaimer Checkbox */}
          <div className={`w-full px-2 mt-2 flex justify-center transition-all duration-300 ${showDisclaimerWarning ? 'scale-105' : ''}`}>
            <label className="flex items-center gap-3 cursor-pointer group">
              <div className="relative flex items-center justify-center shrink-0">
                <input
                  type="checkbox"
                  checked={isDisclaimerAccepted}
                  onChange={(e) => {
                    setIsDisclaimerAccepted(e.target.checked);
                    if (e.target.checked) setShowDisclaimerWarning(false);
                  }}
                  className={`peer appearance-none w-5 h-5 rounded-md border bg-white/5 checked:bg-primary checked:border-primary transition-all duration-300 ${showDisclaimerWarning ? 'border-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]' : 'border-white/10'}`}
                />
                <div className="absolute opacity-0 peer-checked:opacity-100 pointer-events-none transition-opacity duration-300">
                  <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>
              <div className="text-[11px] text-foreground/50 leading-relaxed group-hover:text-foreground/70 transition-colors select-none">
                {t.disclaimer.checkbox}
                <Link
                  href="/regulamin"
                  target="_blank"
                  className="text-primary hover:text-primary/80 underline underline-offset-2 transition-colors font-medium"
                >
                  {t.disclaimer.terms}
                </Link>
                {t.disclaimer.and}
                <Link
                  href="/polityka-prywatnosci"
                  target="_blank"
                  className="text-primary hover:text-primary/80 underline underline-offset-2 transition-colors font-medium"
                >
                  {t.disclaimer.privacy}
                </Link>
              </div>
            </label>
          </div>
        </motion.div>

        {/* Center Concentric Visualizer & Button */}
        <div className={`z-10 flex flex-col items-center w-full relative flex-1 justify-center min-h-[180px] md:min-h-[280px]`}>

          {/* Status Text - always visible, cycles through states */}
          <div className="h-14 md:h-16 mb-2 md:mb-4 flex flex-col items-center justify-end z-10">
            <AnimatePresence mode="wait">
              {isAnalyzing ? (
                <motion.div
                  key={analyzingText}
                  initial={{ opacity: 0, y: 10, filter: "blur(4px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, y: -10, filter: "blur(4px)" }}
                  transition={{ duration: 0.4 }}
                  className="flex flex-col items-center text-center px-2"
                >
                  <h2 className="text-2xl font-bold tracking-wide mb-2 text-foreground">{t.loadingAI}</h2>
                  <p className="text-xs font-semibold tracking-widest text-purple-400/80 uppercase">{analyzingText}</p>
                </motion.div>
              ) : pendingFiles.length > 0 ? (
                <motion.div
                  key={`pending-${pendingHint}`}
                  initial={{ opacity: 0, y: 10, filter: "blur(4px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, y: -10, filter: "blur(4px)" }}
                  transition={{ duration: 0.4 }}
                  className="flex flex-col items-center text-center px-2"
                >
                  <h2 className="text-2xl font-bold tracking-wide mb-2 text-foreground">{t.auto.status.ready}</h2>
                  <p className="text-sm text-[#00D1FF]/70 font-medium tracking-wide">{PENDING_HINTS[pendingHint]}</p>
                </motion.div>
              ) : (
                <motion.div
                  key={isRecording ? 'recording' : 'idle'}
                  initial={{ opacity: 0, y: 10, filter: "blur(4px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, y: -10, filter: "blur(4px)" }}
                  transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                  className="flex flex-col items-center text-center px-2"
                >
                  <h2 className={`text-2xl font-bold tracking-wide mb-2 ${isRecording ? 'text-foreground' : 'text-foreground/90'}`}>
                    {activeMode === 'visual'
                      ? (isRecording ? t.auto.audioOpening : t.auto.visualTitle)
                      : (isRecording ? (isDemoMode ? t.demoMode : t.auto.audioListening) : t.auto.audioTap)}
                  </h2>
                  <p className="text-sm text-foreground/50 font-medium tracking-wide text-center px-4">
                    {activeMode === 'visual'
                      ? t.auto.visualSub
                      : (isRecording
                        ? (isDemoMode ? t.auto.audioSubDemo : t.auto.audioSubSrc)
                        : t.auto.audioSubReq)
                    }
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="relative flex items-center justify-center w-[180px] h-[180px] md:w-[200px] md:h-[200px]">

            {/* Concentric Rings (Solid circles expanding outwards and fading) */}
            <div className="absolute inset-0 pointer-events-none" style={{ display: activeMode === 'visual' ? 'none' : 'block' }}>
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  ref={(el) => { ringsRef.current[i] = el; }}
                  className="absolute top-1/2 left-1/2 w-[140px] h-[140px] md:w-[160px] md:h-[160px] rounded-full bg-[#00D1FF] mix-blend-screen transition-opacity duration-200"
                  style={{
                    transform: 'translate(-50%, -50%) scale(1)',
                    opacity: 0,
                    willChange: 'transform, opacity, background-color'
                  }}
                />
              ))}
            </div>

            {/* Continuous Subtle Waves (Emanating from center) */}
            <AnimatePresence>
              {isRecording && activeMode === 'audio' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 2 }}
                  className="absolute inset-0 pointer-events-none flex items-center justify-center"
                >
                  {[...Array(3)].map((_, i) => (
                    <motion.div
                      key={`wave-${i}`}
                      initial={{ scale: 1, opacity: 0 }}
                      animate={{ scale: 4, opacity: [0, 0.15, 0, 0] }}
                      transition={{
                        scale: {
                          duration: 6,
                          repeat: Infinity,
                          delay: i * 2,
                          ease: "easeOut",
                        },
                        opacity: {
                          duration: 6,
                          repeat: Infinity,
                          delay: i * 2,
                          times: [0, 0.2, 0.8, 1], // Fades out completely before the scale ends to prevent popping
                          ease: "easeInOut",
                        }
                      }}
                      className="absolute w-[160px] h-[160px] rounded-full border-[1.5px] border-[#00D1FF]/40 mix-blend-screen"
                      style={{ willChange: 'transform, opacity' }}
                    />
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Idle Breathing Animation for Rings (only when not recording) */}
            {!isRecording && activeMode === 'audio' && (
              <motion.div
                animate={{ scale: [1, 1.1, 1], opacity: [0.03, 0.1, 0.03] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute inset-0 pointer-events-none flex items-center justify-center"
              >
                <div className="w-[180px] h-[180px] rounded-full bg-[#00D1FF] blur-md" />
              </motion.div>
            )}

            {/* Central Button (Steve Jobs / Apple Style with Logo) */}
            <motion.button
              onClick={pendingFiles.length > 0 ? handleAnalyzeClick : toggleRecording}
              style={{ pointerEvents: isAnalyzing ? 'none' : 'auto' }}
              disabled={isAnalyzing}
              animate={
                isRecording || pendingFiles.length > 0
                  ? {
                    scale: [0.98, 1.02, 0.98],
                    opacity: 1,
                    boxShadow: [
                      '0 0 30px rgba(0, 209, 255, 0.2), inset 0 2px 20px rgba(0, 209, 255, 0.1)',
                      '0 0 60px rgba(0, 209, 255, 0.4), inset 0 2px 20px rgba(0, 209, 255, 0.2)',
                      '0 0 30px rgba(0, 209, 255, 0.2), inset 0 2px 20px rgba(0, 209, 255, 0.1)'
                    ]
                  }
                  : {
                    scale: 1,
                    boxShadow: '0 20px 50px rgba(0,0,0,0.5), inset 0 2px 10px rgba(255,255,255,0.05)'
                  }
              }
              transition={
                isRecording || pendingFiles.length > 0
                  ? { duration: 4, repeat: Infinity, ease: "easeInOut" }
                  : { duration: 0.8, ease: [0.16, 1, 0.3, 1] }
              }
              className={`relative z-10 w-[140px] h-[140px] md:w-[160px] md:h-[160px] rounded-full flex items-center justify-center overflow-hidden backdrop-blur-3xl group ${pendingFiles.length > 0 ? 'bg-surface-elevated/60 border border-blue-500/20' : 'bg-surface-elevated/90 border border-foreground/[0.08]'}`}
            >
              {/* Inner Depth Shadow */}
              <div className="absolute inset-0 rounded-full shadow-[inset_0_4px_20px_rgba(0,0,0,0.6)] pointer-events-none" />

              {/* Minimalist Mic Icon inside button */}
              <div className="relative z-10 flex flex-col items-center justify-center select-none">
                <motion.div
                  animate={isRecording ? { opacity: [0.6, 1, 0.6], scale: [0.95, 1.05, 0.95] } : { opacity: 1, scale: 1 }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                  className="relative flex items-center justify-center p-4"
                >
                  {isAnalyzing ? (
                    <Loader2 className="w-12 h-12 stroke-[1.5] text-purple-400 animate-spin" />
                  ) : pendingFiles.length > 0 ? (
                    <Sparkles className="w-12 h-12 stroke-[1.5] text-[#00D1FF]/60" />
                  ) : activeMode === 'audio' ? (
                    <Mic className={`w-12 h-12 stroke-[1.5] transition-colors duration-500 ${isRecording ? 'text-primary' : 'text-foreground/80'}`} />
                  ) : (
                    <Camera className={`w-12 h-12 stroke-[1.5] transition-colors duration-500 ${isRecording ? 'text-foreground' : 'text-foreground/80'}`} />
                  )}

                  {isAnalyzing && (
                    <motion.div
                      className="absolute inset-0 border-2 border-transparent border-t-purple-400 border-r-purple-400/50 rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                    />
                  )}

                  {(isRecording || isAnalyzing) && activeMode === 'audio' && (
                    <motion.div
                      className={`absolute inset-0 blur-xl rounded-full -z-10 ${isAnalyzing ? 'bg-purple-500' : 'bg-[#00D1FF]'}`}
                      animate={{ opacity: [0.2, 0.5, 0.2] }}
                      transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                    />
                  )}
                </motion.div>
              </div>
            </motion.button>

            {/* Analyzing glow ring (visible when isAnalyzing) */}
            <AnimatePresence>
              {isAnalyzing && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.3, 0.7, 0.3] }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute inset-0 rounded-full pointer-events-none border border-purple-400/30"
                />
              )}
            </AnimatePresence>

            {/* Small Mic Button overlapping main button */}
            {pendingFiles.length === 0 && !isRecording && !isAnalyzing && (
              <motion.button
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={(e) => { e.stopPropagation(); setActiveMode('audio'); startRecording(); }}
                className="absolute bottom-[5px] left-[-5px] z-30 w-14 h-14 rounded-full bg-surface border-4 border-background flex items-center justify-center shadow-lg group/mic overflow-hidden"
              >
                <div className="absolute inset-0 bg-primary/10 animate-pulse" />
                <Mic className="w-6 h-6 text-primary relative z-10" />
              </motion.button>
            )}

            <input type="file" accept="audio/*,video/*,image/*" capture="environment" multiple className="hidden" ref={fileInputRef} onChange={handleFileChange} />
            <input type="file" accept="audio/*,video/*,image/*" multiple className="hidden" ref={galleryInputRef} onChange={handleFileChange} />

            {/* Error Message Display */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  className="absolute bottom-[-80px] flex items-center gap-2 bg-orange-500/10 border border-orange-500/20 text-orange-400 px-4 py-2 rounded-xl backdrop-blur-md z-50"
                >
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm font-medium">{error}</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Selected Files Management */}
        <AnimatePresence>
          {pendingFiles.length > 0 && !isRecording && !isAnalyzing && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="w-full px-6 pt-2 flex gap-2 overflow-x-auto pb-2 scrollbar-hide shrink-0 relative z-20"
            >
              {pendingFiles.map((file, i) => (
                <div key={i} className="flex items-center gap-2 bg-surface/80 border border-foreground/[0.05] rounded-full pl-3 pr-1 py-1 shrink-0 backdrop-blur-md">
                  <span className="text-[10px] text-foreground/80 font-medium truncate max-w-[80px]" title={file.name}>
                    {file.name.length > 12 ? file.name.substring(0, 10) + '...' : file.name || t.shazam.screenshot}
                  </span>
                  <button
                    onClick={(e) => { e.stopPropagation(); setPendingFiles(prev => prev.filter((_, idx) => idx !== i)); }}
                    className="w-5 h-5 rounded-full bg-foreground/5 hover:bg-red-500/20 text-foreground/50 hover:text-red-400 flex items-center justify-center transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom Buttons */}
        <motion.div
          animate={{ opacity: (isRecording || isAnalyzing) ? 0 : 1, y: (isRecording || isAnalyzing) ? 20 : 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="w-full px-6 flex gap-3 md:gap-4 pt-1 md:pt-4 shrink-0 relative z-20"
          style={{ pointerEvents: (isRecording || isAnalyzing) ? 'none' : 'auto' }}
        >
          <button
            onClick={() => galleryInputRef.current?.click()}
            className={`flex-1 group relative overflow-hidden flex flex-col items-center justify-center gap-2 md:gap-2.5 transition-all duration-500 py-3 md:py-5 rounded-[24px] md:rounded-[32px] border backdrop-blur-3xl shadow-[0_8px_32px_rgba(0,0,0,0.3)] ${pendingFiles.length > 0
              ? 'bg-[#00D1FF]/10 border-[#00D1FF]/30'
              : 'bg-white/5 hover:bg-white/10 border-white/10'
              }`}
          >
            <div className={`w-9 h-9 md:w-10 md:h-10 rounded-full transition-all duration-500 flex items-center justify-center shadow-inner border ${pendingFiles.length > 0 ? 'bg-[#00D1FF]/10 border-[#00D1FF]/20' : 'bg-foreground/5 group-hover:bg-foreground/10 border-foreground/5'
              }`}>
              {isLoadingFile ? (
                <Loader2 className="w-4 h-4 text-[#00D1FF] animate-spin" />
              ) : pendingFiles.length > 0 ? (
                <span className="text-[#00D1FF] text-base">✓</span>
              ) : activeMode === 'audio' ? (
                <Upload className="w-4 h-4 text-foreground/60 group-hover:text-foreground transition-colors" />
              ) : (
                <ImageIcon className="w-4 h-4 text-foreground/60 group-hover:text-foreground transition-colors" />
              )}
            </div>
            <span className={`text-[10px] font-semibold uppercase tracking-widest transition-colors text-center px-2 truncate w-full ${isLoadingFile ? 'text-[#00D1FF]/60' :
              pendingFiles.length > 0 ? 'text-[#00D1FF]/80' :
                'text-foreground/50 group-hover:text-foreground/90'
              }`}>
              {isLoadingFile ? t.auto.labels.loading : pendingFiles.length > 0 ? `✓ ${t.auto.labels.ready} (${pendingFiles.length}/4)` : t.auto.uploadFiles}
            </span>
          </button>

          <button onClick={() => setIsContextModalOpen(true)} className="flex-1 group relative overflow-hidden flex flex-col items-center justify-center gap-2 md:gap-2.5 bg-white/5 hover:bg-white/10 transition-all duration-500 py-3 md:py-5 rounded-[24px] md:rounded-[32px] border border-white/10 backdrop-blur-3xl shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
            <div className="w-9 h-9 md:w-10 md:h-10 rounded-full bg-foreground/5 group-hover:bg-foreground/10 group-hover:scale-105 transition-all duration-500 flex items-center justify-center shadow-inner border border-foreground/5">
              <FileText className="w-4 h-4 text-foreground/60 group-hover:text-foreground transition-colors" />
            </div>
            <span className="text-[10px] font-semibold text-foreground/50 group-hover:text-foreground/90 uppercase tracking-widest transition-colors text-center px-2 truncate w-full">
              {diagnosticContext ? t.auto.contextReady : t.auto.uploadContext}
            </span>
          </button>
        </motion.div>
      </div>

      <AnimatePresence>
        {isFollowUp && followUpRequest && !isAnalyzing && !isRecording && pendingFiles.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-0 z-[60] flex flex-col"
          >
            {/* Blurred background */}
            <div className="absolute inset-0 bg-background/80 backdrop-blur-xl" />

            {/* Content */}
            <div className="relative z-10 flex flex-col h-full pt-16 px-6 pb-8">
              {/* Top badge */}
              <div className="flex items-center justify-center mb-6">
                <div className="flex items-center gap-2 bg-[#00D1FF]/10 border border-[#00D1FF]/20 rounded-full px-4 py-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00D1FF] animate-pulse" />
                  <span className="text-[10px] font-bold tracking-widest text-[#00D1FF] uppercase">{t.auto.step2}</span>
                </div>
              </div>

              {/* Message */}
              <div className="flex-1 flex flex-col items-center justify-center">
                <h2 className="text-3xl font-bold text-foreground mb-6 leading-tight text-center">{t.auto.oneStepToDiagnosis}</h2>
                <div className="w-full bg-surface/40 border border-foreground/[0.06] rounded-[20px] p-5 backdrop-blur-sm">
                  <p className="text-[10px] font-bold tracking-widest text-[#00D1FF]/70 uppercase mb-2">{t.auto.aiInstruction}</p>
                  <p className="text-foreground/80 text-sm leading-relaxed">
                    {followUpRequest.message}
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col gap-3 w-full max-w-sm mx-auto">
                {/* Primary: Record */}
                <button
                  onClick={() => {
                    if (activeMode === 'audio') startRecording();
                    else fileInputRef.current?.click();
                  }}
                  className="w-full flex items-center justify-center gap-3 bg-[#00D1FF]/10 hover:bg-[#00D1FF]/15 border border-[#00D1FF]/25 hover:border-[#00D1FF]/40 text-[#00D1FF] font-bold tracking-wider uppercase text-[11px] py-5 px-6 rounded-[24px] transition-all active:scale-95"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    <span>{t.auto.recordLive}</span>
                  </div>
                </button>

                {/* Secondary: Upload photo/video */}
                <button
                  onClick={() => galleryInputRef.current?.click()}
                  className="w-full flex items-center justify-center gap-3 bg-surface/50 hover:bg-surface border border-foreground/[0.06] hover:border-foreground/[0.12] text-foreground/80 hover:text-foreground font-bold tracking-wider uppercase text-[11px] py-4 px-6 rounded-[24px] transition-all active:scale-95"
                >
                  <ImageIcon className="w-4 h-4" />
                  {t.auto.addFromLibrary}
                </button>

                {/* Skip */}
                <button
                  onClick={() => {
                    if (firstFiles.length > 0) runDiagnosis(firstFiles, true);
                  }}
                  className="w-full flex items-center justify-center text-foreground/30 hover:text-foreground/60 font-medium text-xs py-3 transition-colors"
                >
                  {t.auto.skipTest}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isContextModalOpen && <ContextModal
          onClose={() => setIsContextModalOpen(false)}
          onSave={(data) => { setDiagnosticContext(data); setIsContextModalOpen(false); }}
          initialData={diagnosticContext || undefined} />}
        {isDiagnosisOpen && diagnosisData && <DiagnosisReport onClose={() => {
          setIsDiagnosisOpen(false);
          setDiagnosisData(null);
          setDiagnosisId(undefined);
          setDiagnosticContext(null);
          setVehicleMake('');
          setFirstFiles([]);
          setActiveMode('visual');
          // Set to idle mode implicitly
        }} data={diagnosisData} diagnosisId={diagnosisId} onOpenChat={onOpenChat} />}
      </AnimatePresence>

      {/* Context Reminder Overlay */}
      <AnimatePresence>
        {showContextReminder && (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 40 }}
            className="absolute inset-0 z-[75] flex flex-col overflow-y-auto"
          >
            <div className="absolute inset-0 bg-background/90 backdrop-blur-2xl" />
            <div className="relative z-10 flex flex-col h-full pt-14 px-6 pb-8 justify-center">
              <div className="flex-1 flex flex-col justify-center gap-4 text-center max-w-sm mx-auto">
                <div className="w-16 h-16 rounded-full bg-[#00D1FF]/10 border border-[#00D1FF]/20 flex items-center justify-center mx-auto mb-2">
                  <FileText className="w-8 h-8 text-[#00D1FF]" />
                </div>
                <h2 className="text-2xl font-bold text-foreground">{t.auto.labels.noContextTitle}</h2>
                {t.auto.labels.noContextDesc}
              </div>
              <div className="flex flex-col gap-3 mt-8">
                <button
                  onClick={() => { setShowContextReminder(false); setIsContextModalOpen(true); }}
                  className="w-full flex items-center justify-center gap-2 bg-[#00D1FF]/10 hover:bg-[#00D1FF]/15 border border-[#00D1FF]/25 text-[#00D1FF] font-bold text-sm py-4 px-6 rounded-[20px] transition-all"
                >
                  {t.auto.labels.fillData}
                </button>
                <button
                  onClick={() => {
                    if (pendingFiles.length > 0) {
                      setShowContextReminder(false);
                      runDiagnosis(pendingFiles, false);
                    } else {
                      setShowContextReminder(false);
                      setIsAnalyzing(false);
                      setActiveMode('visual');
                    }
                  }}
                  className="w-full flex items-center justify-center gap-2 bg-foreground/5 hover:bg-foreground/10 border border-foreground/[0.05] text-foreground/60 font-semibold text-sm py-4 px-6 rounded-[20px] transition-all"
                >
                  {t.auto.labels.continueWithoutContext}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sticky Error Overlay — persistent, always readable */}
      <AnimatePresence>
        {stickyError && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute inset-0 z-[80] flex flex-col items-center justify-center p-8"
          >
            <div className="absolute inset-0 bg-background/90 backdrop-blur-xl" />
            <div className="relative z-10 flex flex-col items-center text-center max-w-sm">
              <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mb-6">
                <span className="text-3xl">⚠️</span>
              </div>
              <h3 className="text-xl font-bold text-foreground mb-3">{t.auto.status.error}</h3>
              <p className="text-foreground/60 text-sm leading-relaxed mb-8">{stickyError}</p>
              <button
                onClick={() => { setStickyError(null); setError(null); }}
                className="w-full bg-foreground/10 hover:bg-foreground/15 border border-foreground/10 text-foreground font-semibold text-sm py-4 rounded-[20px] transition-all"
              >
                {t.auto.labels.closeAndTryAgain}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <DisclaimerModal
        isOpen={isDisclaimerModalOpen}
        onClose={() => setIsDisclaimerModalOpen(false)}
      />
      <NoCreditsModal
        isOpen={showNoCreditsModal}
        onClose={() => setShowNoCreditsModal(false)}
      />
      <LoginRequiredModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
      />
    </div>
  );
}
