"use client";

import React, { useState, useRef } from 'react';
import { X, Camera, Mic, Paperclip, FileImage } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';

export interface DiagnosticContextData {
  mileage: string;
  description: string;
  tags: string[];
  condition: string | null;
  obdCodes: string;
  contextFiles: File[];
  yearEngine?: string;
}

export function ContextModal({ onClose, onSave, initialData, variant = 'car' }: {
  onClose: () => void;
  onSave: (data: DiagnosticContextData) => void;
  initialData?: DiagnosticContextData;
  variant?: 'car' | 'bike';
}) {
  const { t } = useLanguage();
  const [description, setDescription] = useState(initialData?.description || '');
  const [selectedTags, setSelectedTags] = useState<string[]>(initialData?.tags || []);
  const [selectedCondition, setSelectedCondition] = useState<string | null>(initialData?.condition || null);
  const [mileage, setMileage] = useState(initialData?.mileage || '');
  const [obdCodes, setObdCodes] = useState(initialData?.obdCodes || '');
  const [yearEngine, setYearEngine] = useState(initialData?.yearEngine || '');
  const [contextFiles, setContextFiles] = useState<File[]>(initialData?.contextFiles || []);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setContextFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    }
  };

  const quickTags = variant === 'bike'
    ? t.context.quickTagsBike
    : t.context.quickTagsCar;

  const conditions = variant === 'bike'
    ? t.context.whenBike
    : t.context.whenCar;

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter(t => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-background/90 backdrop-blur-sm text-foreground font-sans flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
      <div className="w-full max-w-2xl bg-surface-elevated border border-foreground/[0.03] rounded-[2rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-8 border-b border-foreground/[0.03]">
          <div>
            <h2 className="text-2xl font-semibold text-foreground tracking-tight">{t.context.title}</h2>
            <p className="text-sm text-muted mt-1 font-medium">{t.context.subtitle}</p>
          </div>
          <button onClick={onClose} className="w-10 h-10 rounded-full bg-[#131823] border border-foreground/[0.03] flex items-center justify-center text-muted hover:text-foreground hover:bg-surface-hover transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-8 overflow-y-auto custom-scrollbar flex flex-col gap-8">

          {/* Rok i silnik dla aut */}
          {variant === 'car' && (
            <div className="space-y-4">
              <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                {t.auto.yearEnginePlaceholder}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={yearEngine}
                  onChange={(e) => setYearEngine(e.target.value)}
                  placeholder={t.auto.yearEnginePlaceholder}
                  className="w-full bg-background border border-foreground/[0.03] rounded-2xl p-5 text-sm text-foreground placeholder:text-muted focus:outline-none focus:border-primary/30 focus:ring-1 focus:ring-blue-500/30 transition-all font-medium"
                />
              </div>
            </div>
          )}

          {/* Przebieg */}
          <div className="space-y-4">
            <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
              {variant === 'bike' ? t.context.mileageBike : t.context.mileageCar}
            </label>
            <div className="relative">
              <input
                type="text"
                value={mileage}
                onChange={(e) => setMileage(e.target.value)}
                placeholder={variant === 'bike' ? t.context.mileageBikePh : t.context.mileageCarPh}
                className="w-full bg-background border border-foreground/[0.03] rounded-2xl p-5 text-sm text-foreground placeholder:text-muted focus:outline-none focus:border-primary/30 focus:ring-1 focus:ring-blue-500/30 transition-all font-medium"
              />
            </div>
          </div>

          {/* Kody OBD-II lub Model osprzętu */}
          <div className="space-y-4">
            <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
              {variant === 'bike' ? t.context.obdBike : t.context.obdTitle}
            </label>
            <div className="relative">
              <input
                type="text"
                value={obdCodes}
                onChange={(e) => setObdCodes(e.target.value)}
                placeholder={variant === 'bike' ? t.context.obdBikePh : t.context.obdPh}
                className={`w-full bg-background border border-foreground/[0.03] rounded-2xl p-5 text-sm text-foreground placeholder:text-muted focus:outline-none focus:border-primary/30 focus:ring-1 focus:ring-blue-500/30 transition-all font-medium ${variant === 'car' ? 'uppercase' : ''}`}
              />
            </div>
          </div>

          {/* Opis problemu */}
          <div className="space-y-4">
            <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted">{t.context.descTitle}</label>
            <div className="relative">
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={variant === 'bike' ? t.context.descBikePh : t.context.descCarPh}
                className="w-full bg-background border border-foreground/[0.03] rounded-2xl p-5 text-sm text-foreground placeholder:text-muted focus:outline-none focus:border-primary/30 focus:ring-1 focus:ring-blue-500/30 transition-all resize-none h-32"
              />
              <input type="file" multiple accept="image/*,video/*" className="hidden" ref={fileInputRef} onChange={handleFileChange} />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-4 right-4 px-4 h-10 rounded-full bg-[#131823] border border-foreground/[0.03] flex items-center justify-center gap-2 text-muted hover:text-foreground hover:bg-surface-hover transition-colors"
                title={t.context.attachmentTooltip}
              >
                <Paperclip className="w-4 h-4" />
                {contextFiles.length > 0 && <span className="text-xs font-bold">{contextFiles.length}</span>}
              </button>
            </div>
            {contextFiles.length > 0 && (
              <div className="flex gap-2 flex-wrap">
                {contextFiles.map((f, i) => (
                  <div key={i} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-500/10 text-blue-400 rounded-lg text-[10px] uppercase font-bold border border-blue-500/20">
                    <FileImage className="w-3 h-3" />
                    <span className="truncate max-w-[100px]">{f.name}</span>
                    <button onClick={() => setContextFiles(prev => prev.filter((_, index) => index !== i))} className="ml-1 hover:text-red-400">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Szybkie tagi */}
          <div className="space-y-4">
            <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted">{t.context.quickTagsTitle}</label>
            <div className="flex flex-wrap gap-3">
              {quickTags.map(tag => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={`px-5 py-3 rounded-2xl text-sm font-medium transition-all border ${selectedTags.includes(tag)
                    ? 'bg-primary/10 border-primary/30 text-primary shadow-[0_0_15px_rgba(59,130,246,0.1)]'
                    : 'bg-[#131823] border-foreground/[0.03] text-muted hover:border-foreground/[0.06] hover:text-foreground/90'
                    }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Kiedy występuje */}
          <div className="space-y-4">
            <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted">{t.context.whenOccurs}</label>
            <div className="grid grid-cols-2 gap-3">
              {conditions.map(cond => (
                <button
                  key={cond}
                  onClick={() => setSelectedCondition(cond === selectedCondition ? null : cond)}
                  className={`px-5 py-4 rounded-2xl text-sm font-medium text-center transition-all border ${selectedCondition === cond
                    ? 'bg-primary/10 border-primary/30 text-primary shadow-[0_0_15px_rgba(59,130,246,0.1)]'
                    : 'bg-[#131823] border-foreground/[0.03] text-muted hover:border-foreground/[0.06] hover:text-foreground/90'
                    }`}
                >
                  {cond}
                </button>
              ))}
            </div>
          </div>

          {/* Dodaj zdjęcie */}
          <div className="space-y-4">
            <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted">{t.context.visuals}</label>
            <button className="w-full bg-[#131823] border border-foreground/[0.03] rounded-2xl p-8 flex flex-col items-center justify-center gap-3 hover:bg-surface-hover hover:border-foreground/[0.06] transition-all group">
              <div className="w-12 h-12 rounded-full bg-background border border-foreground/[0.03] flex items-center justify-center group-hover:scale-105 transition-transform">
                <Camera className="w-5 h-5 text-muted group-hover:text-foreground/90" />
              </div>
              <div className="flex flex-col items-center gap-1">
                <span className="text-[10px] font-bold tracking-[0.15em] text-muted uppercase">{t.context.addPhoto}</span>
                <span className="text-xs text-muted font-medium">{t.context.optional}</span>
              </div>
            </button>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-8 border-t border-foreground/[0.03] bg-surface-elevated flex gap-4">
          <button onClick={onClose} className="flex-1 py-4 rounded-2xl font-bold text-xs tracking-[0.15em] uppercase text-muted bg-[#131823] border border-foreground/[0.03] hover:bg-surface-hover hover:text-foreground/90 transition-colors">
            {t.cancel}
          </button>
          <button onClick={() => onSave({ mileage, description, tags: selectedTags, condition: selectedCondition, obdCodes, contextFiles, yearEngine })} className="flex-[2] py-4 rounded-2xl font-bold text-xs tracking-[0.15em] uppercase text-foreground bg-blue-600 hover:bg-primary transition-colors shadow-[0_0_20px_rgba(37,99,235,0.2)]">
            {t.context.save}
          </button>
        </div>

      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #1A2130;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #2A3441;
        }
      `}</style>
    </div>
  );
}
